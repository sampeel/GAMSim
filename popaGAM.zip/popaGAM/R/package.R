#' Fit additive presence-only/presence-absence models.
#'
#' Fit additive presence-only/presence-absence models with TMB and JAGS.
#'
#' @name popaGAM-package
#' @docType package
#' @author Simon Wotherspoon
NULL
