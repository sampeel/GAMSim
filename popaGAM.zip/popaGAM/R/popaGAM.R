##' Compute effective degrees of freedom for the presence and bias terms of the model
##'
##' Fill this in later
##' @title Effective Degrees of Freedom
##' @param p.gam The partial gam object for the presence component
##' @param b.gam The partial gam object for the bias component
##' @param offset Model offset
##' @param betaA Array of coefficients for the presence component
##' @param betaB Vector of coefficients for the bias component
##' @param rhoA Array of smoothing parameters for the presence component
##' @param rhoB Vector of smoothing parameters for the presence component
##' @importFrom stats poisson binomial
##' @return a list with elements
##' \item{\code{edfA}}{array of effective degrees of freedom for the presence terms}
##' \item{\code{edfB}}{vector of effective degrees of freedom for the bias terms}
computeEDF <- function(p.gam,b.gam,offset,betaA,betaB,rhoA,rhoB) {

  isP <- b.gam$isP
  N <- length(isP)
  isB <- !isP
  Pfam <- poisson(link=log)
  Bfam <- binomial(link=cloglog)

  A <- p.gam$X
  B <- b.gam$X[,-1,drop=FALSE]
  betaB <- betaB[-1]

  mY <- ncol(betaA)
  mA <- ncol(A)
  mB <- ncol(B)
  mbeta <- mY*mA+mB
  js <- (mY*mA)+seq_len(mB)

  ## Compute XTWX
  XTWX <- matrix(0,mbeta,mbeta)
  for(k in seq_len(mY)) {
    is <- ((k-1)*mA)+seq_len(mA)
    eta0 <- B%*%betaB
    eta <- as.vector(A%*%betaA[,k] + offset[,k])
    eta[isP] <- eta[isP]+eta0

    ## Calculate weights
    mu <- eta
    mu[isP] <- Pfam$linkinv(eta[isP])
    mu[isB] <- Bfam$linkinv(eta[isB])
    mu.eta <- eta
    mu.eta[isP] <- Pfam$mu.eta(eta[isP])
    mu.eta[isB] <- Bfam$mu.eta(eta[isB])
    varmu <- mu
    varmu[isP] <- Pfam$variance(mu[isP])
    varmu[isB] <- Bfam$variance(mu[isB])
    w <- (mu.eta^2)/varmu

    ## Contribution to XTWX
    XTWX[is,is] <- crossprod(A,w*A)
    XTWX[js,is] <- t(XTWX[is,js] <- crossprod(A[isP,,drop=FALSE],w[isP]*B))
    XTWX[js,js] <- XTWX[js,js]+crossprod(B,w[isP]*B)
  }

  ## Add smoothing penalties
  XTWXS <- XTWX
  lambdaA <- exp(rhoA)
  lambdaB <- exp(rhoB)
  for(i in seq_along(p.gam$S)) {
    S <- p.gam$S[[i]]
    for(k in seq_len(mY)) {
      is <- (p.gam$off[i]-1+(k-1)*mA)+seq_len(ncol(S))
      XTWXS[is,is] <- XTWXS[is,is]+lambdaA[i,k]*S
    }
  }
  for(i in seq_along(b.gam$S)) {
    S <- p.gam$S[[i]]
    is <- (b.gam$off[i]-2+mY*mA)+seq_len(ncol(S))
    XTWXS[is,is] <- XTWXS[is,is]+lambdaB[i]*S
  }

  ## Compute edf for the two components
  edf <- diag(solve(XTWXS,XTWX))
  edfA <- matrix(edf[seq_len(mY*mA)],mA,mY)
  edfB <- edf[(mY*mA)+seq_len(mB)]

  list(edfA=edfA,edfB=c(1,edfB))
}


##' Initialize gam object
##'
##' These are slightly enhanced versions of the mgcv function of the same name.
##' @title Initialize GAM Component
##' @param formula formula.
##' @param data Dataframe containing responses and covariates.
##' @param isP logical indicating which obervations as presence only
##' @param diagonalize Should the penalties be diagonalized
##' @param center Should the species specific bias term be centered
##' @importFrom stats model.frame model.response na.pass
##' @importFrom mgcv interpret.gam
##' @return Partial gam object
##' @rdname gam.setup
gam.setup <- function(formula,data,isP=NULL,diagonalize=FALSE,center=FALSE) {

  if(is.null(isP)) {
    ## This is the bias formula -> subset to just the presence only data
    gp <- interpret.gam(formula)
    mf <- model.frame(gp$fake.formula,data,na.action=na.pass)
    isP <- model.response(mf)
    mf <- mf[isP,,drop=FALSE]
    data <- data[isP,,drop=FALSE]
  } else {
    ## This is the presence formula -> add bias terms
    formula <- update.formula(formula,.~.+`(Bias)`)
    bias <- if(!center) ifelse(isP,1,0) else scale(ifelse(isP,1,0),scale=FALSE,center=TRUE)
    data <- cbind(data,`(Bias)`=bias)
    gp <- interpret.gam(formula)
    mf <- model.frame(gp$fake.formula,data,na.action=na.pass)
  }
  pterms <- attr(model.frame(gp$pf,data,na.action=na.pass),"terms")
  gam <- mgcv:::gam.setup(gp,pterms=pterms,data=mf,
                          knots=NULL,sp=NULL,H=NULL,
                          absorb.cons=TRUE,sparse.cons=FALSE,select=TRUE,
                          idLinksBases=TRUE,scale.penalty=TRUE,
                          diagonal.penalty=diagonalize)
  gam$model <- mf
  gam$terms <- attr(mf,"terms")
  gam$var.summary <- mgcv:::variable.summary(gp$pf,as.list(data[,all.vars(gp$fake.formula[-2])]),nrow(mf))
  gam$formula <- formula
  gam$rank <- ncol(gam$X)
  gam$isP <- isP
  gam
}



##' Fit popa additive model with TMB
##'
##' Fill this out later.
##' @title POPA Additive Model.
##' @param p.formula Presence formula.
##' @param b.formula Bias formula.
##' @param data Dataframe containing responses and covariates.
##' @param area Vector of cell areas.
##' @param verbose Should tracing be enabled.
##' @param control Control parameters for nlminb.
##' @return yes please.
##' @useDynLib popaGAM
##' @importFrom TMB MakeADFun sdreport
##' @importFrom stats update.formula nlminb
##' @importFrom mgcv interpret.gam
##' @export
popaTMB <- function(p.formula,b.formula,data,area=1,verbose=FALSE,
                    control=list(eval.max=2000,iter.max=1500,rel.tol=1e-5)) {

  cl <- match.call()

  ## Deconstruct b.formula
  b.gam <- gam.setup(b.formula,data)
  isP <- b.gam$isP
  B1 <- b.gam$X[,seq_len(b.gam$nsdf),drop=FALSE]
  B2 <- b.gam$X[,-seq_len(b.gam$nsdf),drop=FALSE]
  ## Adjust intercepts
  if(b.gam$assign[1]!=0) stop("b.formula must contain an intercept")
  B1 <- B1[,-1,drop=FALSE]

  ## Deconstruct p.formula
  p.gam <- gam.setup(p.formula,data,isP)
  Y <- p.gam$y
  A1 <- p.gam$X[,seq_len(p.gam$nsdf),drop=FALSE]
  A2 <- p.gam$X[,-seq_len(p.gam$nsdf),drop=FALSE]
  offset <- matrix(log(area),nrow(Y),ncol(Y))

  ## For each smooth term extract parameter range and penalty matrices
  tmA <- matrix(0L,length(p.gam$smooth),3)
  SA <- list()
  for(i in seq_along(p.gam$smooth)) {
    tmA[i,1] <- as.integer(p.gam$smooth[[i]]$first.para-p.gam$nsdf)
    tmA[i,2] <- as.integer(p.gam$smooth[[i]]$last.para-p.gam$nsdf)
    tmA[i,3] <- as.integer(length(p.gam$smooth[[i]]$S))
    for(s in p.gam$smooth[[i]]$S)
      SA[[length(SA)+1]] <- s
  }
  if(length(SA))
    names(SA) <- paste0("SA",seq_along(SA))

  ## For each smooth term extract parameter range and penalty matrices
  tmB <- matrix(0L,length(b.gam$smooth),3)
  SB <- list()
  for(i in seq_along(b.gam$smooth)) {
    tmB[i,1] <- as.integer(b.gam$smooth[[i]]$first.para-b.gam$nsdf)
    tmB[i,2] <- as.integer(b.gam$smooth[[i]]$last.para-b.gam$nsdf)
    tmB[i,3] <- as.integer(length(b.gam$smooth[[i]]$S))
    for(s in b.gam$smooth[[i]]$S)
      SB[[length(SB)+1]] <- s
  }
  if(length(SB))
    names(SB) <- paste0("SB",seq_along(SB))


  tmbdata <- list(Y=Y,A1=A1,A2=A2,B1=B1,B2=B2,offset=offset,
                  family=as.integer(isP),
                  tmA=tmA,tmB=tmB,SA=SA,SB=SB)

  tmbpars <- list(betaA1=matrix(0,ncol(A1),ncol(Y)),
                  betaA2=matrix(0,ncol(A2),ncol(Y)),
                  betaB1=double(ncol(B1)),
                  betaB2=double(ncol(B2)),
                  rhoA=matrix(log(1),length(SA),ncol(Y)),
                  rhoB=as.double(rep(log(1),length(SB))))
  obj <- MakeADFun(tmbdata,tmbpars,random=c("betaA2","betaB2"),DLL="popaGAM",silent=!verbose)
  ## Minimize objective function
  opt <- suppressWarnings(
    nlminb(obj$par, obj$fn, obj$gr,control=control))
  rep <- sdreport(obj,getJointPrecision=TRUE)

  ## Extract estimates and full covariance
  par <- obj$env$last.par.best
  V <- if(is.null(rep$jointPrecision)) rep$cov.fixed else solve(rep$jointPrecision)


  ## Interleave A coefs and covariance
  ks <- rbind(matrix(seq_len(ncol(A1)*ncol(Y)),ncol(A1),ncol(Y)),
              matrix(seq_len(ncol(A2)*ncol(Y)),ncol(A2),ncol(Y))+ncol(A1)*ncol(Y))
  betaA <- matrix(par[ks],ncol(A1)+ncol(A2),ncol(Y))
  dimnames(betaA) <- list(p.gam$term.names,colnames(Y))
  varA <- array(0,dim(ks)[c(1,1,2)])
  for(j in seq_len(ncol(ks)))
    varA[,,j] <- V[ks[,j],ks[,j]]
  dimnames(varA) <- list(p.gam$term.names,p.gam$term.names,colnames(Y))

  ## Extract B coefs and covariance
  k0 <- length(betaA)
  ks <- seq_len(ncol(B1)+ncol(B2))+k0
  betaB <- par[ks]
  varB <- V[ks,ks]

  ## Extract A smoothing parameters
  k0 <- k0+length(betaB)
  ks <- seq_len(length(SA)*ncol(Y))+k0
  rhoA <- matrix(par[ks],length(SA),ncol(Y))
  dimnames(rhoA) <- list(names(p.gam$sp),colnames(Y))

  ## Extract B smoothing parameters
  k0 <- k0 + length(rhoA)
  ks <- seq_len(length(SB))+k0
  rhoB <- par[ks]
  names(rhoB) <- names(b.gam$sp)

  ## Pad B coefs with zero intercept
  betaB <- c(0,betaB)
  names(betaB) <- b.gam$term.names
  varB <- cbind(0,rbind(0,varB))
  dimnames(varB) <- list(b.gam$term.names,b.gam$term.names)

  edf <- computeEDF(p.gam,b.gam,offset,betaA,betaB,rhoA,rhoB)


  r <- list(p.gam=p.gam,b.gam=b.gam,
            betaA=betaA,varA=varA,betaB=betaB,varB=varB,
            rhoA=rhoA,rhoB=rhoB,edfA=edf$edfA,edfB=edf$edfB,
            call=cl,
            ## Keep TMB objects
            TMBobj=obj,TMBrep=rep)
  class(r) <- "popaGAM"
  r
}



##' Plot method for popaGAM objects.
##'
##' @title Plot popaGAM smooths.
##' @param x a popaGAM object
##' @param species index of the species to plot terms for, or 0 to plot the common bias terms.
##' @param ... arguments to plot.gam
##' @importFrom mgcv plot.gam
##' @export
plot.popaGAM <- function(x,species=0,...) {
  if(species > 0) {
    n <- nrow(x$betaA)
    g <- x$p.gam
    g$coefficients <- x$betaA[,species]
    g$edf <- x$edfA[,species]
    g$rho <- x$rhoA[,species]
    g$Vp <- x$varA[,,species]
    plot.gam(g,...)
  } else {
    g <- x$b.gam
    g$coefficients <- x$betaB
    g$edf <- x$edfB
    g$rho <- x$rhoB
    g$Vp <- x$varB
    plot.gam(g,...)
  }
}



##' Construct code and data for JAGS model
##'
##' Fill this out later.
##' @title JAGS Model
##' @param p.gam partial gam object for presence component
##' @param b.gam partial gam object for bias component
##' @param jags.data partial data list
##' @return A list with elements
##' \item{\code{jags.model}}{the model script for jags}
##' \item{\code{Slist}}{the list of penalty matrices}
jagsModel <- function(p.gam,b.gam,jags.data) {

  is.diagonal <- function(x) {
    diag(x) <- 0
    max(abs(x)) < 1.0E-8
  }

  ## JAGS code for likelihood
  jags.likelihood <- paste(
    "  for(j in 1:nY){",
    "    for(i in 1:mP) {",
    "      Y[i,j] ~ dpois(mu[i,j])",
    "      log(mu[i,j]) <- inprod(A[i,],betaA[,j])+inprod(B[i,],betaB)+offset[i,j]",
    "    }",
    "    for(i in (mP+1):(mP+mB)) {",
    "      Y[i,j] ~ dbern(mu[i,j])",
    "      cloglog(mu[i,j]) <- inprod(A[i,],betaA[,j])+inprod(B[i,],betaB)+offset[i,j]",
    "    }",
    "  }",
    sep="\n")


  ## JAGS code for species specific smooths
  jags.smooth <- "     ## Species specific smooths"
  k <- 0
  for(s in seq_along(p.gam$smooth)) {
    if(all(sapply(p.gam$smooth[[s]]$S,is.diagonal))) {
      ds <- paste0("1:",p.gam$smooth[[s]]$last.para-p.gam$smooth[[s]]$first.para+1)
      p0 <- p.gam$smooth[[s]]$first.para-1
      S <- lapply(p.gam$smooth[[s]]$S,diag)
      ks <- k+seq_along(S)
      names(S) <- paste0("SA",ks)
      jags.smooth <- paste(jags.smooth,
                           paste0("     TauA",s,"[",ds,",j] <- ",paste(paste0("lambdaA[",ks,",j]"),names(S),sep="*",collapse="+")),
                           paste0("     for(k in ",ds,") {"),
                           paste0("       betaA[k+",p0,",j] ~ dnorm(0,TauA",s,"[k,j])"),
                           paste0("     }"),
                           sep="\n")
    } else {
      ds <- paste0("1:",p.gam$smooth[[s]]$last.para-p.gam$smooth[[s]]$first.para+1)
      ps <- paste0(p.gam$smooth[[s]]$first.para,":",p.gam$smooth[[s]]$last.para)
      S <- p.gam$smooth[[s]]$S
      ks <- k+seq_along(S)
      names(S) <- paste0("SA",ks)
      jags.smooth <- paste(jags.smooth,
                           paste0("     TauA",s,"[",ds,",",ds,",j] <- ",paste(paste0("lambdaA[",ks,",j]"),names(S),sep="*",collapse="+")),
                           paste0("     betaA[",ps,",j] ~ dmnorm(zeroP[",ps,"],TauA",s,"[",ds,",",ds,",j])"),
                           sep="\n")
    }
    k <- k + length(S)
    jags.data <- c(jags.data,S)
  }
  if(length(p.gam$smooth) > 0) {
    jags.smooth <- paste(
      "  for(j in 1:nY){",
      jags.smooth,
      "  }",
      sep="\n")
  }

  ## JAGS code for species independent smooths
  k <- 0
  for(s in seq_along(b.gam$smooth)) {
    if(all(sapply(b.gam$smooth[[s]]$S,is.diagonal))) {
      ## Adjust for missing intercept
      ds <- paste0("1:",b.gam$smooth[[s]]$last.para-b.gam$smooth[[s]]$first.para+1)
      p0 <- b.gam$smooth[[s]]$first.para-2
      S <- lapply(p.gam$smooth[[s]]$S,diag)
      ks <- k+seq_along(S)
      names(S) <- paste0("SB",ks)
      jags.smooth <- paste(jags.smooth,
                           paste0("  TauB",s," <- ",paste(paste0("lambdaB[",ks,"]"),names(S),sep="*",collapse="+")),
                           paste0("  for(k in ",ds,") {"),
                           paste0("    betaB[k+",p0,"] ~ dnorm(0,TauB",s,"[k])"),
                           paste0("  }"),
                           sep="\n")
    } else {
      ## Adjust for missing intercept
      ps <- paste0(b.gam$smooth[[s]]$first.para-1,":",b.gam$smooth[[s]]$last.para-1)
      S <- b.gam$smooth[[s]]$S
      ks <- k+seq_along(S)
      names(S) <- paste0("SB",ks)
      jags.smooth <- paste(jags.smooth,
                           paste0("  TauB",s," <- ",paste(paste0("lambdaB[",ks,"]"),names(S),sep="*",collapse="+")),
                           paste0("  betaB[",ps,"] ~ dmnorm(zeroB[",ps,"],TauB",s,")"),
                           sep="\n")
    }
    k <- k + length(S)
    jags.data <- c(jags.data,S)
  }

  ## JAGS code for priors
  jags.prior <- paste(
    if(p.gam$nsdf>0)
      paste(
        "  for(j in 1:nY) {",
        "    for(i in 1:npP) {",
        "      betaA[i,j] ~ dnorm(0,0.001)",
        "    }",
        sep="\n"),
    if(length(p.gam$S)>0)
      paste(
        "    for(i in 1:nsP) {",
        "      lambdaA[i,j] ~ dgamma(1.2,0.12)",
        "      rhoA[i,j] <- log(lambdaA[i,j])",
        "    }",
        sep="\n"),
    "  }",
    if(b.gam$nsdf>1)
      paste(
        "  for(i in 1:npB) {",
        "    betaB[i] ~ dnorm(0,0.001)",
        "  }",
        sep="\n"),
    if(length(b.gam$smooth)>0)
      paste(
        "  for(i in 1:nsB) {",
        "    lambdaB[i] ~ dgamma(1.2,0.12)",
        "    rhoB[i] <- log(lambdaB[i])",
        "  }",
        sep="\n"),
    sep="\n")


  jags.model <- paste("model {",
                      "  ## Likelihood",
                      jags.likelihood,
                      "  ## Smooth",
                      jags.smooth,
                      "  ## Prior",
                      jags.prior,
                      "}",
                      sep="\n")

  list(model=jags.model,data=jags.data)
}



##' Fit popa additive model with JAGS
##'
##' Fill this out later.
##' @title POPA Additive Model.
##' @param p.formula Presence formula.
##' @param b.formula Bias formula.
##' @param data Dataframe containing responses and covariates.
##' @param area Vector of cell areas.
##' @param diagonalize Whether to diagonalize the smoothing penalties.
##' @return yes please.
##' @importFrom stats model.frame model.response na.pass
##' @importFrom mgcv interpret.gam
##' @importFrom rjags jags.model
##' @export
popaJAGS <- function(p.formula,b.formula,data,area=1,diagonalize=FALSE) {

  cl <- match.call()

  ## Reorder data to bring presence only data to the front
  gp <- interpret.gam(b.formula)
  mf <- model.frame(gp$fake.formula,data,na.action=na.pass)
  ord <- model.response(mf)
  ord <- c(which(ord),which(!ord))
  data <- data[ord,]

  ## Deconstruct b.formula
  b.gam <- gam.setup(b.formula,data,diagonalize=diagonalize)
  isP <- b.gam$isP
  B <- b.gam$X
  ## Adjust intercepts
  if(b.gam$assign[1]!=0) stop("b.formula must contain an intercept")
  B <- B[,-1,drop=FALSE]

  ## Deconstruct p.formula, adding species specific Bias term
  p.gam <-  gam.setup(p.formula,data,isP,diagonalize=diagonalize,center=TRUE)
  Y <- p.gam$y
  A <- p.gam$X
  offset <- matrix(log(area),nrow(Y),ncol(Y))[ord,]

  ## Pad B with zero rows
  B <- rbind(B,matrix(0,sum(ifelse(isP,0,1)),ncol(B)))

  ## Create data for JAGS
  jags.data <- list(
    Y=Y,
    A=A,
    B=B,
    offset=offset,
    nY=ncol(Y),
    mP=sum(ifelse(isP,1,0)),
    mB=sum(ifelse(isP,0,1)),
    npP=p.gam$nsdf,
    npB=b.gam$nsdf-1,
    nsP=length(p.gam$S),
    nsB=length(b.gam$S),
    zeroP=double(ncol(A)),
    zeroB=double(ncol(B)))

  ## Construct Jags model script and penalty matrices
  jags <- jagsModel(p.gam,b.gam,jags.data)

  vars <- c("betaA","betaB")
  inits <- list(betaA=matrix(0.0,ncol(A),ncol(Y)),
                betaB=double(ncol(B)))
  if(length(p.gam$S)>0) {
    inits$lambdaA <- matrix(1.0,length(p.gam$S),ncol(Y))
    vars <- c(vars,"rhoA")
  }
  if(length(b.gam$S)>0) {
    inits$lambdaB <- rep(1.0,length(b.gam$S))
    vars <- c(vars,"rhoB")
  }
  jags$inits <- inits
  jags$vars <- vars

  r <- list(p.gam=p.gam,b.gam=b.gam,jags=jags,call=cl)
  class(r) <- "popaJAGS"
  r
}


##' Contruct a popaGAM object from a jags model and samples
##'
##' Fill in later.
##' @title JAGS to popaGAM
##' @param model an object created by \code{\link{popaJAGS}}
##' @param samples MCMC drawn with \code{\link{jags.samples}}
##' @importFrom stats var
##' @return a popaGAM object.
##' @export
jags2popaGAM <- function(model,samples) {

  var1 <- function(x) {
    dim(x) <- c(dim(x)[1],prod(dim(x)[-1]))
    var(t(x))
  }


  ## Extract posterior means and covariances
  betaA <- apply(samples$betaA,1:2,mean)
  dimnames(betaA) <- list(model$p.gam$term.names,colnames(model$p.gam$y))
  varA <- array(0,dim(samples$betaA)[c(1,1,2)])
  for(j in seq_len(dim(samples$betaA)[2]))
    varA[,,j] <- var1(samples$betaA[,j,,,drop=FALSE])
  dimnames(varA) <- list(model$p.gam$term.names,model$p.gam$term.names,colnames(model$p.gam$y))
  betaB <- apply(samples$betaB,1,mean)
  varB <- var1(samples$betaB)
  rhoA <- double(0)
  if(!is.null(samples$rhoA)) {
    rhoA <- apply(samples$rhoA,1:2,mean)
    dimnames(rhoA) <- list(names(model$p.gam$sp),colnames(model$pgam$y))
  }
  rhoB <- double(0)
  if(!is.null(samples$rhoB)) {
    rhoB <- apply(samples$rhoB,1,mean)
    names(rhoB) <- names(model$b.gam$sp)
  }
  offset <- model$jags$data$offset

  ## Pad B coefs with zero intercept
  betaB <- c(0,betaB)
  varB <- cbind(0,rbind(0,varB))
  names(betaB) <- model$b.gam$term.names
  dimnames(varB) <- list(model$b.gam$term.names,model$b.gam$term.names)

  edf <- computeEDF(model$p.gam,model$b.gam,offset,betaA,betaB,rhoA,rhoB)

  r <- list(p.gam=model$p.gam,b.gam=model$b.gam,
            betaA=betaA,varA=varA,betaB=betaB,varB=varB,
            rhoA=rhoA,rhoB=rhoB,edfA=edf$edfA,edfB=edf$edfB,
            call=model$call,
            ## Keep JAGS objects
            JAGSmodel=model,JAGSsamples=samples)
  class(r) <- "popaGAM"
  r
}


##' Print the JAGS script for a popaJAM object
##'
##' @title Print popaJAM objects
##' @param x a popaJAM object
##' @param ... currently ignored
##' @export
print.popaJAGS <- function(x,...) {
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
  cat(x$jags$model,sep="\n")
}


##' Print the call for a popaGAM object
##'
##' @title Print popaGAM objects
##' @param x a popaGAM object
##' @param ... currently ignored
##' @export
print.popaGAM <- function(x,...) {
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
  cat("\nA:\n")
  print(x$betaA)
  cat("\nB:\n")
  print(x$betaB)
}



