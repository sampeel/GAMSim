#define TMB_LIB_INIT R_init_mypkg
#include <TMB.hpp>

using namespace density;
using namespace Eigen;
using namespace tmbutils;

// Multivariate Normal density parameterized in terms of precision
template<class Type>
Type dmvnormp(vector<Type> x, matrix<Type> Q, int give_log=0){
  Type logdetQ = atomic::logdet(Q);
  Type quadform = (x*(Q*x)).sum();
  Type logres = Type(.5)*(logdetQ - quadform - x.size()*Type(log(2*M_PI)));
  if(give_log)return logres; else return exp(logres);
}

template<class Type>
 Type dnormp(Type x, Type mean, Type tau, int give_log=0) {
  Type logres=Type(.5)*(log(tau)-log(Type(2*M_PI))-tau*pow((x-mean),2));
  //return 1/(sqrt(2*M_PI)*sd)*exp(-.5*pow((x-mean)/sd,2));
  if(give_log)return logres; else return exp(logres);
}
VECTORIZE4_ttti(dnormp)

/* List of matrices */
template<class Type>
struct LOM_t : vector<matrix<Type> > {
  LOM_t(SEXP x){  /* x = List passed from R */
    (*this).resize(LENGTH(x));
    for(int i=0; i<LENGTH(x); i++){
      SEXP sm = VECTOR_ELT(x, i);
      (*this)(i) = asMatrix<Type>(sm);
    }
  }
};


template<class Type>
Type objective_function<Type>::operator() () {
  DATA_MATRIX(Y);		// Matrix of responses
  DATA_MATRIX(A1);		// Design matrix for parametric species specific component
  DATA_MATRIX(A2);		// Design matrix for smooth species specific component
  DATA_MATRIX(B1);		// Design matrix for parametric common component
  DATA_MATRIX(B2);		// Design matrix for smooth common component
  DATA_MATRIX(offset);          // Matrix of offsets
  DATA_IVECTOR(family);		// Vector of integers indicating family type
  DATA_IMATRIX(tmA);            // Index of first/last parameter and number of smoothing parameters for each smooth term
  DATA_IMATRIX(tmB);            // Index of first/last parameter and number of smoothing parameters for each smooth term
  DATA_STRUCT(SA,LOM_t);	// Penalties for species specific component
  DATA_STRUCT(SB,LOM_t);	// Penalties for common component


  PARAMETER_MATRIX(betaA1);	// Coeffs for parametric species specific component
  PARAMETER_MATRIX(betaA2);	// Coeffs for smooth species specific component
  PARAMETER_VECTOR(betaB1);	// Coeffs for parametric common component
  PARAMETER_VECTOR(betaB2);	// Coeffs for smooth common component

  PARAMETER_MATRIX(rhoA);	// Smoothing parameters
  PARAMETER_VECTOR(rhoB);	// Smoothing parameters

  // Smoothing parameters - add small lower bound
  matrix<Type> lambdaA = exp(rhoA.array())+Type(0.01);
  vector<Type> lambdaB = exp(rhoB)+Type(0.01);


  // Negative log likelihood
  Type nll = Type(0.0);

  // Linear predictor
  vector<Type> eta0 = B1*betaB1+B2*betaB2;
  matrix<Type> eta = A1*betaA1+A2*betaA2+offset;

  // Mean - one column for each species
  matrix<Type> mu(Y.rows(),Y.cols());

  // Contribution to neg log lik from the responses
  for(int j=0; j<eta.cols(); ++j) {
    int p = 0;
    for(int i=0; i<eta.rows(); ++i) {
      if(family(i)==0) {
	// Binomial
	mu(i,j) = Type(1) - exp(-exp(eta(i,j)));
        nll -= dbinom(Y(i,j),Type(1.0),mu(i,j),true);
      } else {
        // Include bias term
        eta(i,j) += eta0(p);
        p++;
	// Poisson
	mu(i,j) = exp(eta(i,j));
	nll -= dpois(Y(i,j),mu(i,j),true);
      }
    }
  }

  // Smoothing penalties

  // Index of the penalty matrix in the penalty list
  int s = 0;

  // Loop over species
  for(int j=0; j<betaA2.cols(); ++j) {
    s = 0;
    // Loop over smooth terms
    for(int tm=0; tm<tmA.rows(); ++tm) {
      // Build up total penalty
      matrix<Type> S = lambdaA(s,j)*SA(s);
      ++s;
      for(int k=1; k<tmA(tm,2); ++k) {
	S += lambdaA(s,j)*SA(s);
	++s;
      }
      int i1 = tmA(tm,0)-1;
      int i2 = tmA(tm,1);
      vector<Type> beta = betaA2.col(j).segment(i1,i2-i1);
      nll -= dmvnormp(beta,S,true);
    }
  }

  s = 0;
  // Loop over terms
  for(int tm=0; tm<tmB.rows(); ++tm) {
    // Build up total penalty
    matrix<Type> S = lambdaB(s)*SB(s);
    ++s;
    for(int k=1; k<tmB(tm,2); ++k) {
      S += lambdaB(s)*SB(s);
      ++s;
    }
    // Penalize parameters
    int i1 = tmB(tm,0)-1;
    int i2 = tmB(tm,1);
    vector<Type> beta = betaB2.segment(i1,i2-i1);
    nll -= dmvnormp(beta,S,true);
  }

  return nll;
}
